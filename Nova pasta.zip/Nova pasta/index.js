// ================= IMPORTS =================

const {
    Client,
    GatewayIntentBits,
    Partials,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    Events
} = require('discord.js');

const express = require('express');
const axios = require('axios');
const fs = require('fs');


// ================= APP =================

const app = express();

const client = new Client({

    intents: [

        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent

    ],

    partials: [

        Partials.Channel

    ]
});


// ================= CONFIG =================

const TOKEN = "MTUwNjc4NDU2OTkxMzkwNTI0Mg.GGNrvo.VznMN6Vr42BO4itQfeCqMrB1OX6MHf7Vso9WQk";

const CLIENT_ID = "1506784569913905242";

const CLIENT_SECRET = "1izkA7Ziq3yC2yDbDs36Hua5lY-kbf28";

const GUILD_ID = "1478772148964298916";

const ROLE_ID = "1506806346920755243";

const CHANNEL_ID = "1506806146340753509";

const REDIRECT_URI =
"http://localhost:3000/callback";


// ================= DATABASE =================

if (!fs.existsSync('users.json')) {

    fs.writeFileSync(
        'users.json',
        JSON.stringify([], null, 2)
    );
}


// ================= SITE =================

app.get('/callback', async (req, res) => {

    const code = req.query.code;

    try {

        // pega token
        const tokenRes = await axios.post(

            'https://discord.com/api/oauth2/token',

            new URLSearchParams({

                client_id: CLIENT_ID,
                client_secret: CLIENT_SECRET,
                grant_type: 'authorization_code',
                code: code,
                redirect_uri: REDIRECT_URI

            }),

            {

                headers: {

                    'Content-Type':
                    'application/x-www-form-urlencoded'

                }

            }
        );

        const tokenData =
        tokenRes.data;

        const access_token =
        tokenData.access_token;

        const refresh_token =
        tokenData.refresh_token;


        // pega usuario
        const userRes = await axios.get(

            'https://discord.com/api/users/@me',

            {

                headers: {

                    Authorization:
                    `Bearer ${access_token}`

                }

            }
        );

        const user = userRes.data;


        // salva json
        let users = JSON.parse(

            fs.readFileSync('users.json')

        );

        users = users.filter(
            u => u.id !== user.id
        );

        users.push({

            id: user.id,
            access_token,
            refresh_token

        });

        fs.writeFileSync(

            'users.json',

            JSON.stringify(
                users,
                null,
                2
            )

        );


        // adiciona no servidor
        await axios.put(

`https://discord.com/api/guilds/${GUILD_ID}/members/${user.id}`,

            {

                access_token

            },

            {

                headers: {

                    Authorization:
                    `Bot ${TOKEN}`

                }

            }
        );


        // pega membro
        const guild =
        await client.guilds.fetch(
            GUILD_ID
        );

        const member =
        await guild.members.fetch(
            user.id
        );


        // adiciona cargo
        await member.roles.add(
            ROLE_ID
        );


        // sucesso
        res.send(`

        <body style="

            background:#0d1117;
            color:white;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            font-family:sans-serif;

        ">

            <div style="text-align:center;">

                <h1 style="color:lime;">
                ✅ Verificado!
                </h1>

                <p>
                Você já pode voltar ao Discord.
                </p>

            </div>

        </body>

        `);

    } catch (err) {

        console.log(
            err.response?.data || err
        );

        res.send('Erro.');
    }
});


// ================= READY =================

client.once(

Events.ClientReady,

async () => {

    console.log(
        `${client.user.tag} online!`
    );

    const channel =
    await client.channels.fetch(
        CHANNEL_ID
    );


const row = new ActionRowBuilder()
.addComponents(
    new ButtonBuilder()
        .setLabel('Verificar')
        .setStyle(ButtonStyle.Link)
        .setURL('https://discord.com/oauth2/authorize?client_id=1506784569913905242&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A3000%2Fcallback&scope=identify%20guilds.join')
);


    // envia embed
    await channel.send({

        content:

`# 🚀 NEXUS AUTH

✅ Clique no botão abaixo para verificar sua conta e liberar acesso automaticamente.`,

        components: [row]

    });

    console.log(
        'Mensagem enviada!'
    );
});


// ================= START =================

app.listen(3000, () => {

    console.log(
        'OAuth online!'
    );
});

client.login(TOKEN);